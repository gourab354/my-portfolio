# 🚀 Complete Setup & Deployment Guide

## Table of Contents
1. [Local Development Setup](#local-development-setup)
2. [Project Customization](#project-customization)
3. [Adding Content](#adding-content)
4. [Deployment Options](#deployment-options)
5. [Post-Deployment](#post-deployment)
6. [Troubleshooting](#troubleshooting)

---

## Local Development Setup

### Step 1: Prerequisites
Make sure you have installed:
- **Node.js** (v16+): https://nodejs.org/
- **Git**: https://git-scm.com/
- **Code Editor**: VS Code recommended (https://code.visualstudio.com/)

Verify installations:
```bash
node --version
npm --version
git --version
```

### Step 2: Clone or Download Project
```bash
# Option A: Clone from Git
git clone https://github.com/gourab354/gourab-portfolio-v2.git
cd gourab-portfolio-v2

# Option B: Download as ZIP and extract
# Then open terminal in the extracted folder
```

### Step 3: Install Dependencies
```bash
npm install
```

This installs all required packages from `package.json`.

### Step 4: Start Development Server
```bash
npm run dev
```

You'll see output like:
```
VITE v5.x.x  ready in xxx ms

➜  Local:   http://localhost:5173/
➜  press h + enter to show help
```

Open http://localhost:5173/ in your browser. The page auto-reloads when you make changes!

---

## Project Customization

### 1. Update Basic Info

**Step 1: Update in Navigation** (`src/components/Navigation.jsx`)
```javascript
// Change the logo/brand name
<motion.div className="...">
  &lt;YOUR_NAME /&gt;  {/* Change this */}
</motion.div>

// Update social links
<a href="https://github.com/YOUR_USERNAME">  {/* Change this */}
  GitHub
</a>
```

**Step 2: Update Social Links in Footer** (`src/components/Footer.jsx`)
```javascript
const socialLinks = [
  {
    icon: Github,
    href: 'https://github.com/YOUR_USERNAME',  // Change this
    label: 'GitHub'
  },
  // ... other links
];
```

### 2. Update Home Page Stats
Edit `src/pages/Home.jsx`:

```javascript
const stats = [
  { label: '3×', value: 'Hackathon Finalist', icon: Trophy, color: '...' },
  // Update these numbers to your achievements
];
```

### 3. Update Skills
In the same file, update the `skills` array:

```javascript
const skills = [
  { 
    category: 'Your Category', 
    items: ['Skill1', 'Skill2', 'Skill3'] 
  },
  // Add your skills
];
```

### 4. Update Featured Project
Update the Smart Medicine Box section with your project:

```javascript
<h3 className="text-3xl font-bold text-white mb-2">
  💊 Your Project Title  {/* Change */}
</h3>
<p className="text-cyan-400 font-mono text-sm">
  Your tech stack  {/* Change */}
</p>
```

---

## Adding Content

### Adding a New Project

1. **Edit `src/pages/Projects.jsx`**
2. **Find the `projects` array**
3. **Add a new object:**

```javascript
{
  id: 7,  // Increment ID
  title: 'Smart IoT System',
  description: 'A complete IoT solution for home automation',
  category: 'hardware',  // hardware, web, ml, backend
  tags: ['ESP32', 'Node.js', 'React'],
  image: '🏠',  // Emoji or image path
  highlights: [
    'Real-time monitoring',
    'Mobile app control',
    'Cloud integration',
  ],
  github: 'https://github.com/yourusername/project',
  demo: 'https://your-demo-link.com'
}
```

### Adding a Certificate

1. **Edit `src/pages/Certificates.jsx`**
2. **Find the `certificates` array in useState**
3. **Add new certificate:**

```javascript
{
  id: 4,
  title: 'AWS Solutions Architect',
  issuer: 'Amazon AWS',
  date: 'January 2024',
  description: 'Professional certification in cloud architecture',
  image: '/certificates/aws-cert.jpg',
  link: 'https://certificate-link.com/verify',
  category: 'course'  // competition, hackathon, award, course
}
```

4. **Upload Certificate Image:**
   - Place image in `public/certificates/` folder
   - Use relative path: `/certificates/filename.jpg`

### Updating About Page

Edit `src/pages/About.jsx` to personalize:

```javascript
// Update your bio
const journey = [
  {
    icon: Zap,
    title: 'Your Title',
    description: 'Your description',
    color: 'from-cyan-400 to-cyan-600'
  },
  // More items...
];

// Update competencies
{title: '🔧 Your Skill', desc: 'Your description' },
```

### Updating Contact Info

Edit `src/pages/Contact.jsx`:

```javascript
const contactMethods = [
  {
    icon: Mail,
    label: 'Email',
    value: 'your.email@example.com',  // Change
    link: 'mailto:your.email@example.com'  // Change
  },
  // ... update other links
];
```

---

## Deployment Options

### Option 1: Deploy to Vercel (Recommended) ⭐

**Why Vercel?**
- Free tier with great features
- Automatic deployment from GitHub
- Fast performance
- Custom domains supported
- Analytics included

**Steps:**

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Portfolio v2 ready for deployment"
   git push origin main
   ```

2. **Connect to Vercel**
   - Go to https://vercel.com
   - Click "New Project"
   - Select your GitHub repository
   - Click "Deploy"
   - Done! Your site is live

3. **Add Custom Domain**
   - In Vercel Dashboard → Settings → Domains
   - Add your custom domain
   - Configure DNS records (Vercel will guide you)

### Option 2: Deploy to Netlify

**Steps:**

1. **Build locally**
   ```bash
   npm run build
   ```

2. **Deploy**
   - Go to https://netlify.com
   - Click "New site from Git"
   - Select your GitHub repo
   - Netlify auto-detects Vite settings
   - Click "Deploy"

3. **Custom Domain**
   - Netlify Dashboard → Domain settings
   - Add your custom domain
   - Update DNS records

### Option 3: Deploy to GitHub Pages

**Steps:**

1. **Create gh-pages branch**
   ```bash
   git branch gh-pages
   ```

2. **Update vite.config.js**
   ```javascript
   export default {
     base: '/gourab-portfolio/',  // Your repo name
     // ... rest
   }
   ```

3. **Build and push**
   ```bash
   npm run build
   git add dist
   git commit -m "Deploy to gh-pages"
   git push origin gh-pages
   ```

4. **Enable in GitHub**
   - Go to repo Settings → Pages
   - Select "gh-pages" branch
   - Your site is live!

### Option 4: Self-Hosted (Linux Server)

```bash
# SSH into your server
ssh user@your-server.com

# Clone repository
git clone https://github.com/yourusername/portfolio.git
cd portfolio

# Install and build
npm install
npm run build

# Serve with Nginx or Apache
# (Configure web server to point to dist/ folder)
```

---

## Post-Deployment

### 1. Verify Everything Works
- [ ] Home page loads correctly
- [ ] All navigation links work
- [ ] Projects page displays all projects
- [ ] Contact form works
- [ ] Mobile responsive
- [ ] Images load properly
- [ ] Animations smooth

### 2. Add to Your Resume
Include portfolio URL:
```
Portfolio: https://your-portfolio.com
```

### 3. Share on Social Media
```
🚀 Just launched my new portfolio!
Built with React, Tailwind CSS, and Framer Motion
Showcasing my IoT projects & achievements
Check it out: https://your-portfolio.com
```

### 4. SEO Optimization

Update `index.html`:
```html
<meta name="description" content="Your professional portfolio - IoT Developer">
<meta name="keywords" content="IoT, Electronics, ESP32, Hardware, Portfolio">
<title>Your Name - IoT Developer & Hardware Enthusiast</title>
```

### 5. Analytics

Add Google Analytics to `index.html`:
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

### 6. Connect Contact Form

**Option A: Formspree**
1. Go to https://formspree.io
2. Create account and project
3. Update form action in `Contact.jsx`

**Option B: EmailJS**
1. Go to https://emailjs.com
2. Get API key
3. Add to Contact.jsx component

---

## Troubleshooting

### Issue: Port 5173 already in use
```bash
# Use different port
npm run dev -- --port 3000
```

### Issue: npm install fails
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Issue: Build fails
```bash
# Check Node version
node --version  # Should be v16+

# Clean and rebuild
rm -rf dist
npm run build
```

### Issue: Images not loading in production
```javascript
// Use correct path with /
import image from '/path/to/image.jpg'
// Or in HTML
<img src="/images/photo.jpg" />
```

### Issue: Routes not working on deployment
```javascript
// Add base URL in vite.config.js
export default {
  base: '/gourab-portfolio/',
}
```

### Issue: Slow loading
```bash
# Analyze bundle
npm run build -- --report

# Optimize images, lazy load components
```

---

## Next Steps

1. **Keep portfolio updated**
   - Add new projects regularly
   - Update achievements and certificates
   - Refresh content quarterly

2. **Collect feedback**
   - Ask people for feedback
   - Monitor analytics
   - Improve based on user behavior

3. **Continuous improvement**
   - Add new features
   - Improve animations
   - Optimize performance

4. **Network**
   - Share on social media
   - Link from GitHub profile
   - Include in job applications
   - Use in interviews

---

**Happy Portfolio Building!** 🎉

For more help, check:
- React docs: https://react.dev
- Tailwind CSS: https://tailwindcss.com/docs
- Framer Motion: https://www.framer.com/motion/
- Vite: https://vitejs.dev/
